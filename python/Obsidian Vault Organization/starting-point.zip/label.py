"""
Phase 3 — LLM Cluster Labeler
Sends each cluster's note titles + snippets to Claude to get:
  - a human-readable topic label
  - a suggested folder name (slug)
  - a one-sentence description

Usage: python label.py cluster_report.json
       python label.py cluster_report.json --out labeled_report.json
"""
import os
import json
import time
import argparse
from pathlib import Path

import anthropic
from rich.console import Console
from rich.progress import track

console = Console()

CLIENT = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY from env


# ---------------------------------------------------------------------------
# Prompt builder
# ---------------------------------------------------------------------------

def build_prompt(cluster: dict) -> str:
    lines = []
    for n in cluster["notes"][:12]:  # cap at 12 samples per cluster
        snippet = _first_words(n["path"], 30)
        lines.append(f'- "{n["title"]}" — {snippet}')

    note_list = "\n".join(lines)
    return f"""You are helping organize an Obsidian markdown vault.
Here are {cluster['size']} notes that were grouped together by semantic similarity:

{note_list}

Based on these notes, respond with a JSON object (no markdown, no preamble) with exactly these fields:
{{
  "topic_label": "Short human-readable topic name (3-6 words)",
  "folder_slug": "lowercase-hyphenated-folder-name",
  "description": "One sentence describing what these notes are about."
}}"""


def _first_words(path_str: str, n: int) -> str:
    try:
        text = Path(path_str).read_text(encoding="utf-8", errors="replace")
        if text.startswith("---"):
            end = text.find("---", 3)
            if end != -1:
                text = text[end + 3:]
        words = text.split()[:n]
        return " ".join(words) + ("…" if len(words) >= n else "")
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# API call
# ---------------------------------------------------------------------------

def label_cluster(cluster: dict, retries: int = 3) -> dict:
    prompt = build_prompt(cluster)
    for attempt in range(retries):
        try:
            msg = CLIENT.messages.create(
                model="claude-haiku-4-5-20251001",   # fast + cheap for labeling
                max_tokens=256,
                messages=[{"role": "user", "content": prompt}],
            )
            raw = msg.content[0].text.strip()
            # strip accidental fences
            if raw.startswith("```"):
                raw = raw.split("\n", 1)[1].rsplit("```", 1)[0]
            return json.loads(raw)
        except (json.JSONDecodeError, IndexError) as e:
            console.print(f"  [yellow]Parse error attempt {attempt+1}: {e}[/yellow]")
            time.sleep(1)
        except anthropic.RateLimitError:
            console.print("  [yellow]Rate limited — waiting 10s…[/yellow]")
            time.sleep(10)
    return {
        "topic_label": f"Cluster {cluster['cluster_id']}",
        "folder_slug": f"cluster-{cluster['cluster_id']:02d}",
        "description": "(labeling failed)",
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Vault cluster labeler — Phase 3")
    parser.add_argument("report", help="cluster_report.json from cluster.py")
    parser.add_argument("--out", default="labeled_report.json")
    args = parser.parse_args()

    if not os.environ.get("ANTHROPIC_API_KEY"):
        console.print(
            "[red]ANTHROPIC_API_KEY not set.[/red] "
            "Export it before running:\n"
            "  export ANTHROPIC_API_KEY=sk-ant-..."
        )
        return

    report = json.loads(Path(args.report).read_text())
    clusters = report["clusters"]

    # Skip UNCLUSTERED (noise) for labeling
    to_label = [c for c in clusters if c["cluster_id"] != -1]
    noise = [c for c in clusters if c["cluster_id"] == -1]

    console.print(
        f"[bold]Labeling {len(to_label)} clusters[/bold] "
        f"via Claude Haiku… ([dim]{len(noise)} noise notes skipped[/dim])"
    )

    for cluster in track(to_label, description="Labeling…"):
        result = label_cluster(cluster)
        cluster.update(result)
        time.sleep(0.3)  # gentle rate limiting

    # Add placeholder for noise
    for c in noise:
        c.update({
            "topic_label": "Unclustered",
            "folder_slug": "_unclustered",
            "description": "Notes that didn't fit any cluster — review manually.",
        })

    out = Path(args.out)
    out.write_text(json.dumps(report, indent=2, ensure_ascii=False))
    console.print(f"\n[green]Labeled report saved →[/green] {out}")
    console.print("Run [bold]report.py[/bold] to generate your human-readable review report.")


if __name__ == "__main__":
    main()
