"""
Phase 1 — Vault Scanner & Deduplicator
Usage: python scan.py /path/to/vaults /another/path ...
       python scan.py --root ~/Documents  # scans recursively for .md files
"""
import sys
import json
import hashlib
import argparse
from pathlib import Path
from datetime import datetime

from rich.console import Console
from rich.table import Table
from rich import print as rprint

console = Console()

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def hash_file(path: Path) -> str:
    """MD5 of file content (fast, good enough for dedup)."""
    h = hashlib.md5()
    h.update(path.read_bytes())
    return h.hexdigest()


def extract_title(path: Path) -> str:
    """Best-effort title: first H1, else YAML frontmatter title, else filename."""
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return path.stem
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("# "):
            return line[2:].strip()
        if line.lower().startswith("title:"):
            return line.split(":", 1)[1].strip().strip('"\'')
    return path.stem


def word_count(path: Path) -> int:
    try:
        return len(path.read_text(encoding="utf-8", errors="replace").split())
    except Exception:
        return 0


def collect_notes(roots: list[Path]) -> list[dict]:
    notes = []
    seen_paths: set[Path] = set()
    for root in roots:
        for md in sorted(root.rglob("*.md")):
            resolved = md.resolve()
            if resolved in seen_paths:
                continue
            seen_paths.add(resolved)
            # skip .obsidian config dirs
            if ".obsidian" in md.parts:
                continue
            notes.append({
                "path": str(md),
                "stem": md.stem,
                "title": extract_title(md),
                "words": word_count(md),
                "hash": hash_file(md),
                "mtime": datetime.fromtimestamp(md.stat().st_mtime).isoformat(),
                "vault": _infer_vault(md, roots),
            })
    return notes


def _infer_vault(path: Path, roots: list[Path]) -> str:
    """Return the name of the root this path lives under."""
    for root in roots:
        try:
            path.relative_to(root)
            return root.name
        except ValueError:
            pass
    return "unknown"


# ---------------------------------------------------------------------------
# Deduplication
# ---------------------------------------------------------------------------

def find_exact_dupes(notes: list[dict]) -> dict[str, list[dict]]:
    """Group notes by content hash. Groups with >1 member are exact dupes."""
    groups: dict[str, list[dict]] = {}
    for n in notes:
        groups.setdefault(n["hash"], []).append(n)
    return {h: g for h, g in groups.items() if len(g) > 1}


def find_near_dupes(
    notes: list[dict], threshold: float = 0.85
) -> list[tuple[dict, dict, float]]:
    """
    Jaccard similarity on word-trigrams.
    Returns pairs with similarity >= threshold.
    Fast enough for <500 notes.
    """
    def trigrams(path_str: str) -> set[str]:
        try:
            words = Path(path_str).read_text(
                encoding="utf-8", errors="replace"
            ).lower().split()
        except Exception:
            return set()
        return {" ".join(words[i:i+3]) for i in range(len(words) - 2)}

    console.print("[dim]Computing near-dupe trigrams…[/dim]")
    sets = [(n, trigrams(n["path"])) for n in notes]

    pairs = []
    for i, (na, sa) in enumerate(sets):
        for nb, sb in sets[i + 1:]:
            if na["hash"] == nb["hash"]:
                continue  # already an exact dupe
            if not sa or not sb:
                continue
            j = len(sa & sb) / len(sa | sb)
            if j >= threshold:
                pairs.append((na, nb, round(j, 3)))
    return sorted(pairs, key=lambda x: -x[2])


# ---------------------------------------------------------------------------
# Reporting
# ---------------------------------------------------------------------------

def print_summary(notes: list[dict], exact: dict, near: list) -> None:
    console.rule("[bold cyan]Vault Scan Summary[/bold cyan]")
    console.print(f"  Total notes found : [bold]{len(notes)}[/bold]")
    console.print(f"  Exact dupe groups : [bold red]{len(exact)}[/bold red]")
    console.print(f"  Near-dupe pairs   : [bold yellow]{len(near)}[/bold yellow]")
    console.print()

    if exact:
        t = Table(title="Exact Duplicates", show_lines=True)
        t.add_column("Hash", style="dim", width=10)
        t.add_column("Copies", justify="right")
        t.add_column("Paths")
        for h, group in list(exact.items())[:20]:
            paths = "\n".join(g["path"] for g in group)
            t.add_row(h[:8], str(len(group)), paths)
        console.print(t)

    if near:
        t = Table(title="Near-Duplicates (top 20)", show_lines=True)
        t.add_column("Sim", justify="right", style="yellow")
        t.add_column("Note A")
        t.add_column("Note B")
        for na, nb, sim in near[:20]:
            t.add_row(str(sim), na["path"], nb["path"])
        console.print(t)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Vault scanner — Phase 1")
    parser.add_argument(
        "roots", nargs="+", help="Vault root directories to scan"
    )
    parser.add_argument(
        "--near-dupe-threshold", type=float, default=0.85,
        help="Jaccard similarity threshold for near-dupe detection (default 0.85)"
    )
    parser.add_argument(
        "--out", default="scan_manifest.json",
        help="Output manifest path (default: scan_manifest.json)"
    )
    args = parser.parse_args()

    roots = [Path(r).expanduser().resolve() for r in args.roots]
    for r in roots:
        if not r.exists():
            console.print(f"[red]Path not found:[/red] {r}")
            sys.exit(1)

    console.print(f"[bold]Scanning {len(roots)} root(s)…[/bold]")
    notes = collect_notes(roots)
    console.print(f"  Found [bold]{len(notes)}[/bold] markdown files.")

    exact = find_exact_dupes(notes)
    near = find_near_dupes(notes, threshold=args.near_dupe_threshold)

    print_summary(notes, exact, near)

    # Save manifest
    manifest = {
        "scanned_at": datetime.now().isoformat(),
        "roots": [str(r) for r in roots],
        "notes": notes,
        "exact_dupe_groups": {
            h: [n["path"] for n in g] for h, g in exact.items()
        },
        "near_dupe_pairs": [
            {"a": na["path"], "b": nb["path"], "similarity": sim}
            for na, nb, sim in near
        ],
    }
    out = Path(args.out)
    out.write_text(json.dumps(manifest, indent=2, ensure_ascii=False))
    console.print(f"\n[green]Manifest saved →[/green] {out}")
    console.print("Run [bold]cluster.py[/bold] next to embed and cluster notes.")


if __name__ == "__main__":
    main()
